# Background Remover Package

This package removes the background from `.jpg` images in the `input/` directory and saves the output in `output/`.

## Installation

```bash
pip install .
